#ifndef _HALCONACTION__H_
#define _HALCONACTION__H_

#include "spdlog/sinks/basic_file_sink.h"
#include "spdlog/sinks/stdout_sinks.h"
#include "spdlog/async.h"
#include "spdlog/sinks/rotating_file_sink.h"
#include "thread"

#include <opencv2/opencv.hpp>
#include <opencv2/cudawarping.hpp>
#include <opencv2/cudaarithm.hpp>

#include <torch/torch.h>
#include <fstream>

#include "stdio.h"

#include "HDevThread.h"
#include "HDevEngineCpp.h"
#include "CommonContent.h"


using namespace cv;
using namespace std;
using namespace HalconCpp;
using namespace HDevEngineCpp;

struct hconAction_middle_result {
	
	HalconCpp::HTuple hv_Row11;
	HalconCpp::HTuple hv_Column11;
	HalconCpp::HTuple hv_Row2;
	HalconCpp::HTuple hv_Column2;

	HalconCpp::HTuple AreaSumModel;  //ģ�����ͨ���
	HalconCpp::HTuple AreaSumModelDila;

	HalconCpp::HObject ho_RegionDifference;


};

struct hconAction_moban {

	hconAction_middle_result mid_result; //�м���

	int now_num = 0;

	int x1 = 0;      //ģ������
	int y1 = 0;
	int x2 = 0;
	int y2 = 0;

	int BlackMin = 0;
	int WhiteMin = 0;
	int BlackMax = 45;
	int WhiteMax = 0;

	float RatioDila = 0;  //���Ҫ /10
	int DiffThr = 0;
	float DiffThrD = 33;   //���Ҫ /10
	int MinArea = 0;
	int MaxArea = 0;

	int XOffSet = 0;
	int YOffSet = 0;
};

class hconAction
{
public:
	explicit hconAction();
	~hconAction();

public:
	Mat HImageToMat(const HalconCpp::HImage& hImg);   //halcon��ʽͼƬת��ΪopencvͼƬ
	Mat HObjectToMat(const HalconCpp::HObject& hObj);
	HalconCpp::HObject MatToHObject(const Mat& image);
	HalconCpp::HImage MatToHImage(const Mat& image);
	void SaveHobjectImg(string path, HObject& Hobject_in);

	void HALCON_Refresh_Model_all(string filePath_moban); //����ģ���ļ�����
	void ImageThreadStart(HalconCpp::HObject& ImageInput); //����ģ��ȶԵ��߳�
	void ImageThreadJoin(vector<Detect_Result>& Result, int& is_detect);
	//void ImageThreadRun(int threadnum, hconAction_moban& ModelID, HalconCpp::HImage& Image);

	void GetDataOfmoban(int num, int& x1, int& y1, int& x2, int& y2);  //��ȡģ����������
	int GetNumOfmoban();
	void SetNowImgNum(int num_now);   //���õ�ǰ���ڴ����ڼ���ͼƬ

	int GetIni(string file_path, string apname, string partname);     //��ȡ����
	int SetIni(string file_path, string apname, string partname, int set_num);   //���ò���

	int ImageToushiChange(HalconCpp::HObject& ho_ImageInput, HalconCpp::HObject& ho_TransImage1);//͸�ӱ任

	unsigned int now_dealImg_num = 0;

	vector<std::thread> Halcon_thread;
	vector<hconAction_moban> Halcon_moban_all;

	HalconCpp::HTuple hv_X1, hv_Y1, hv_Number1;

private:


};



#endif
