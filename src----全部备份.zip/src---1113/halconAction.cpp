#include <iostream>
#include <cstring>
#include <vector>
#include "thread"

#include <opencv2/opencv.hpp>
#include <opencv2/cudawarping.hpp>
#include <opencv2/cudaarithm.hpp>
#define SPDLOG_ACTIVE_LEVEL SPDLOG_LEVEL_TRACE
#include "spdlog/spdlog.h"
#include "spdlog/cfg/env.h"
#include "spdlog/sinks/basic_file_sink.h"
#include "spdlog/sinks/stdout_sinks.h"
#include "spdlog/async.h"
#include "spdlog/sinks/rotating_file_sink.h"

#include <torch/torch.h>
#include <fstream>

#include "stdio.h"
#include <future>

#include "windows.h"

#include "Halcon.h"
#include "HalconCpp.h"

#include "halconAction.h"
#include "HDevThread.h"
#include "HDevEngineCpp.h"

#include "CommonContent.h"

using namespace cv;
using namespace std;
using namespace HalconCpp;
using namespace HDevEngineCpp;

std::mutex halcon_result_mutex;
vector<Detect_Result> Halcon_Result;


HTuple hv_DeviceIdentifier, hv_DeviceHandle;


hconAction::hconAction()
{
    /*HalconԴ��*/

    SPDLOG_INFO("halconAction start!start GPU speed up...");

    //����GPU����
    //QueryAvailableComputeDevices(&hv_DeviceIdentifier);

    //OpenComputeDevice(HTuple(hv_DeviceIdentifier[0]), &hv_DeviceHandle);

    //SetComputeDeviceParam(hv_DeviceHandle, "alloc_pinned", "false");

    //InitComputeDevice(hv_DeviceHandle, "all");

    //ActivateComputeDevice(hv_DeviceHandle);  //����GPU

    SPDLOG_INFO("finish GPU speed up");
}

hconAction::~hconAction()
{
    SPDLOG_INFO("halconAction end!");

    //DeactivateComputeDevice(hv_DeviceHandle);  //ȡ������GPU
}

void get_XY(HObject ho_ImageInput, HTuple* hv_X, HTuple* hv_Y, HTuple* hv_Number)
{

    // Local iconic variables
    HObject  ho_GrayImage, ho_ImageMean, ho_Region;
    HObject  ho_ConnectedRegions, ho_RegionTrans, ho_Contours;
    HObject  ho_ContoursSplit, ho_SortedRegions, ho_ObjectSelected;

    // Local control variables
    HTuple  hv_Row1, hv_Column, hv_Phi, hv_Length1;
    HTuple  hv_Length2, hv_HomMat2D1, hv_Index1, hv_Row, hv_Col;
    HTuple  hv_RowBegin, hv_ColBegin, hv_RowEnd, hv_ColEnd;
    HTuple  hv_Nr, hv_Nc, hv_Dist;

    Rgb1ToGray(ho_ImageInput, &ho_GrayImage);
    // �� ImageToushiChange ����һ��
    MeanImage(ho_GrayImage, &ho_ImageMean, 7, 7);
    //�Ҷ���ֵ�ָ������
    //binary_threshold (ImageMean, Region, 'max_separability', 'light', UsedThreshold)
    Threshold(ho_ImageMean, &ho_Region, 30, 255);
    Connection(ho_Region, &ho_ConnectedRegions);
    SelectShape(ho_ConnectedRegions, &ho_Region, "area", "and", 52297.9, 2e+06);
    SmallestRectangle2(ho_Region, &hv_Row1, &hv_Column, &hv_Phi, &hv_Length1, &hv_Length2);
    VectorAngleToRigid(hv_Row1, hv_Column, hv_Phi, hv_Row1, hv_Column, 0, &hv_HomMat2D1);
    AffineTransImage(ho_GrayImage, &ho_GrayImage, hv_HomMat2D1, "constant", "false");
    AffineTransRegion(ho_Region, &ho_Region, hv_HomMat2D1, "constant");
    //�ı��������״Ϊ͹��
    ShapeTrans(ho_Region, &ho_RegionTrans, "convex");

    //����XLD�����ؼ�������'border'�߿����ص���߿���Ϊ������
    GenContourRegionXld(ho_RegionTrans, &ho_Contours, "border");
    //��XLD�����ָ���߶�  �� ImageToushiChange ����һ��
    SegmentContoursXld(ho_Contours, &ho_ContoursSplit, "lines", 9, 20, 3);
    //�����ı��εĶ���X����
    (*hv_X) = HTuple();
    //�����ı��εĶ���y����
    (*hv_Y) = HTuple();
    //�������������λ������
    SortContoursXld(ho_ContoursSplit, &ho_SortedRegions, "character", "true", "row");
    //����Ԫ���е�����
    CountObj(ho_SortedRegions, &(*hv_Number));
    {
        HTuple end_val26 = (*hv_Number);
        HTuple step_val26 = 1;
        for (hv_Index1 = 1; hv_Index1.Continue(end_val26, step_val26); hv_Index1 += step_val26)
        {
            //��˳��ѡ������
            SelectObj(ho_SortedRegions, &ho_ObjectSelected, hv_Index1);
            //���ֱ��
            GetContourXld(ho_ObjectSelected, &hv_Row, &hv_Col);
            FitLineContourXld(ho_ObjectSelected, "tukey", -1, 0, 5, 2, &hv_RowBegin, &hv_ColBegin,
                &hv_RowEnd, &hv_ColEnd, &hv_Nr, &hv_Nc, &hv_Dist);
            //ͳһ����Ԫ��
            TupleConcat((*hv_X), hv_RowBegin, &(*hv_X));
            TupleConcat((*hv_Y), hv_ColBegin, &(*hv_Y));

        }
    }
    return;
}

Mat hconAction::HImageToMat(const HalconCpp::HImage& hImg)
{

    cv::Mat mat;
    int channels = hImg.CountChannels()[0].I();
    HalconCpp::HImage hImage = hImg.ConvertImageType("byte");

    Hlong hW = 0, hH = 0;
    HalconCpp::HString cType;

    if (channels == 1) {
        void* r = hImage.GetImagePointer1(&cType, &hW, &hH);
        mat.create(int(hH), int(hW), CV_8UC1);
        memcpy(mat.data, static_cast<unsigned char*>(r), int(hW * hH));
    }
    else if (channels == 3) {
        void* r = NULL, * g = NULL, * b = NULL;

        hImage.GetImagePointer3(&r, &g, &b, &cType, &hW, &hH);
        mat.create(int(hH), int(hW), CV_8UC3);

        std::vector<cv::Mat> vec(3);
        vec[0].create(int(hH), int(hW), CV_8UC1);
        vec[1].create(int(hH), int(hW), CV_8UC1);
        vec[2].create(int(hH), int(hW), CV_8UC1);

        memcpy(vec[2].data, static_cast<unsigned char*>(r), int(hW * hH));
        memcpy(vec[1].data, static_cast<unsigned char*>(g), int(hW * hH));
        memcpy(vec[0].data, static_cast<unsigned char*>(b), int(hW * hH));
        cv::merge(vec, mat);
    }
    return mat;
}

Mat hconAction::HObjectToMat(const HalconCpp::HObject& hObj)
{
    HalconCpp::HImage hImg(hObj);
    return HImageToMat(hImg);
}

HalconCpp::HObject hconAction::MatToHObject(const Mat& image)
{
    HalconCpp::HObject Hobj = HalconCpp::HObject();
    int hgt = image.rows;
    int wid = image.cols;
    int i;
    if (image.type() == CV_8UC3)
    {
        std::vector<Mat> imgchannel;
        split(image, imgchannel);
        Mat imgB = imgchannel[0];
        Mat imgG = imgchannel[1];
        Mat imgR = imgchannel[2];
        uchar* dataR = new uchar[hgt * wid];
        uchar* dataG = new uchar[hgt * wid];
        uchar* dataB = new uchar[hgt * wid];
        for (i = 0; i < hgt; i++)
        {
            memcpy(dataR + wid * i, imgR.data + imgR.step * i, wid);
            memcpy(dataG + wid * i, imgG.data + imgG.step * i, wid);
            memcpy(dataB + wid * i, imgB.data + imgB.step * i, wid);
        }
        HalconCpp::GenImage3(&Hobj, "byte", wid, hgt, (Hlong)dataR, (Hlong)dataG, (Hlong)dataB);
        delete[]dataR;
        delete[]dataG;
        delete[]dataB;
        dataR = NULL;
        dataG = NULL;
        dataB = NULL;
    }
    else if (image.type() == CV_8UC1)
    {
        uchar* data = new uchar[hgt * wid];
        for (i = 0; i < hgt; i++)
            memcpy(data + wid * i, image.data + image.step * i, wid);
        HalconCpp::GenImage1(&Hobj, "byte", wid, hgt, (Hlong)data);
        delete[] data;
        data = NULL;
    }
    return Hobj;
}

HalconCpp::HImage hconAction::MatToHImage(const Mat& image)
{
    HalconCpp::HImage hImg(MatToHObject(image));
    return hImg;
}

void hconAction::SaveHobjectImg(string path, HObject &Hobject_in)
{
    Mat out = HObjectToMat(Hobject_in);
    imwrite(path, out);
}

int hconAction::GetIni(string file_path, string apname, string partname)
{
    int num = 0;
    char getchr[10];	//���������ļ��ַ��Ļ�����
    DWORD res;		//����ֵ
    file_path += "config.ini";
    res = GetPrivateProfileString(apname.c_str(), partname.c_str(), "", getchr, sizeof(getchr), file_path.c_str());

    if (res > 0) {//˵���ò�������
        num = atoi(getchr);
    }
    else {
        num = -1;
    }

    //std::cout << "GetIni-------file_path:" << file_path << ",apaname:" << apname <<",partname:" << partname << ",get res:" << to_string(res) << ",get num =" << to_string(num) << std::endl;

    return num;
}

//�������ļ���д����
int hconAction::SetIni(string file_path, string apname, string partname, int set_num)
{
    //����WritePrivateProfileString("LiMing", "Sex", "Man", lpPath);
    string num_str = to_string(set_num);
    WritePrivateProfileString(apname.c_str(), partname.c_str(), num_str.c_str(), file_path.c_str());
}

//����ģ������
void hconAction::HALCON_Refresh_Model_all(string filePath_moban)
{
    int ini_result = 0;
    int moban_num = 1;

    Halcon_moban_all.clear();
    SPDLOG_INFO("HALCON Refresh_Model_all start!moban size:{},path:{}", Halcon_moban_all.size(), filePath_moban);

    /*ģ��ͼ��*/
    string ImageModel_path = filePath_moban + "0.bmp";
    HObject ho_ImageModel;
    ReadImage(&ho_ImageModel, ImageModel_path.c_str());

    while (1) {
        hconAction_moban moban_s;
        string mobanname = "moban" + to_string(moban_num);
        moban_s.x1 = GetIni(filePath_moban, mobanname, "x1");
        if (moban_s.x1 == -1) break;   //�����ļ��޸�ģ�������
        moban_s.y1 = GetIni(filePath_moban, mobanname, "y1");
        moban_s.x2 = GetIni(filePath_moban, mobanname, "x2");
        moban_s.y2 = GetIni(filePath_moban, mobanname, "y2");

        moban_s.BlackMin = GetIni(filePath_moban, mobanname, "BlackMin");
        moban_s.WhiteMin = GetIni(filePath_moban, mobanname, "WhiteMin");
        moban_s.BlackMax = GetIni(filePath_moban, mobanname, "BlackMax");
        moban_s.WhiteMax = GetIni(filePath_moban, mobanname, "WhiteMax");

        moban_s.RatioDila = (float)GetIni(filePath_moban, mobanname, "RatioDila") / 10.0;
        moban_s.DiffThr = GetIni(filePath_moban, mobanname, "DiffThr");
        moban_s.DiffThrD = (float)GetIni(filePath_moban, mobanname, "DiffThrD") / 10.0;
        moban_s.MinArea = GetIni(filePath_moban, mobanname, "MinArea");
        moban_s.MaxArea = GetIni(filePath_moban, mobanname, "MaxArea");

        moban_s.XOffSet = GetIni(filePath_moban, mobanname, "XOffSet");
        moban_s.YOffSet = GetIni(filePath_moban, mobanname, "YOffSet");

        moban_s.now_num = moban_num;

        /*ģ�����꣺Row(y),Col(x)*/
        HalconCpp::HTuple Row1(moban_s.y1);
        HalconCpp::HTuple Col1(moban_s.x1);
        HalconCpp::HTuple Row2(moban_s.y2);
        HalconCpp::HTuple Col2(moban_s.x2);

        HalconCpp::HObject ho_ModelRegion, ho_GrayImage, ho_ImageMean, ho_Region, ho_ConnectedRegions;
        HalconCpp::HObject ho_RegionTrans, ho_Contours, ho_ContoursSplit, ho_SortedRegions, ho_ObjectSelected;
        HalconCpp::HObject ho_TemplateImage, ho_TemplateGray, ho_RegionModel;
        HalconCpp::HObject ho_RegionDilation, ho_RegionDifference;
        HalconCpp::HTuple hv_AreaModel, hv_CterRowModel, hv_CenterColModel;

        //��ȡģ���6���ǵ������ModelX, ModelY�ͽǵ���ModelNumber
        get_XY(ho_ImageModel, &hv_ModelX, &hv_ModelY, &hv_ModelNumber);

        GenRectangle1(&ho_ModelRegion, Row1, Col1, Row2, Col2);
        //��ȡģ������ModelRegion�����Ͻ�����Row11, Column11�����½�����Row2, Column2
        SmallestRectangle1(ho_ModelRegion, &moban_s.mid_result.hv_Row11, &moban_s.mid_result.hv_Column11, &moban_s.mid_result.hv_Row2, &moban_s.mid_result.hv_Column2);
        //��ģ��ͼƬ�Ͻ�ȡģ������ModelRegion���õ�ģ������ͼƬTemplateImage
        ReduceDomain(ho_ImageModel, ho_ModelRegion, &ho_TemplateImage);

        //��ֵ�ָ������Black��White�ֱ�����ڵ�׵�
        HalconCpp::HTuple hv_BlackMin(moban_s.BlackMin);
        HalconCpp::HTuple hv_WhiteMin(moban_s.WhiteMin);
        HalconCpp::HTuple hv_BlackMax(moban_s.BlackMax);
        HalconCpp::HTuple hv_WhiteMax(moban_s.WhiteMax);
        HalconCpp::HTuple hv_RatioDila(moban_s.RatioDila);

        //��ģ������ͼƬTemplateImageת��Ϊ�Ҷ�ͼTemplateGray
        Rgb1ToGray(ho_TemplateImage, &ho_TemplateGray);
        //�ԻҶ�ͼTemplateGray���ж�ֵ�����õ�����RegionModel
        Threshold(ho_TemplateGray, &ho_RegionModel, hv_BlackMin.TupleConcat(hv_WhiteMin), hv_BlackMax.TupleConcat(hv_WhiteMax));
        //��ȡ����RegionModel�����AreaModel���е���������CterRowModel, CenterColModel��Ŀǰû���õ���������ܻ��õ�
        AreaCenter(ho_RegionModel, &hv_AreaModel, &hv_CterRowModel, &hv_CenterColModel);
        moban_s.mid_result.AreaSumModel = hv_AreaModel.TupleSum();
        //������RegionModel�������ʹ������õ������������RegionDilation��RatioDilaΪ���ͱ���
        DilationCircle(ho_RegionModel, &ho_RegionDilation, hv_RatioDila);
        //��ģ������ModelRegion�����ͺ������RegionDilationȥ�����õ��µ�����RegionDifference
        Difference(ho_ModelRegion, ho_RegionDilation, &moban_s.mid_result.ho_RegionDifference);
        
        //std::cout << "HALCON Refresh_Model_all moban:" << to_string(moban_s.now_num) << ",y1:" << to_string(moban_s.y1) << ",x1:" << to_string(moban_s.x1) << ",RatioDila:" << to_string(hv_RatioDila[0].D())<<
        //    ",hv_Row11:" << to_string(moban_s.mid_result.hv_Row11[0].D()) << ",hv_Column11:" << to_string(moban_s.mid_result.hv_Column11[0].D()) << ",hv_Row2:" << to_string(moban_s.mid_result.hv_Row2[0].D()) << ",hv_Column2:" << to_string(moban_s.mid_result.hv_Column2[0].D())
        //<< std::endl;

        SPDLOG_INFO("HALCON Refresh_Model_all push moban now_num:{:d},y1:{:d},x1:{:d},RatioDila:{:f},DiffThrD:{:f},hv_Row11:{:f},hv_Column11:{:f},hv_Row2:{:f},hv_Column2:{:f}",
            moban_s.now_num, moban_s.y1, moban_s.x1, moban_s.RatioDila, moban_s.DiffThrD, moban_s.mid_result.hv_Row11.D(), moban_s.mid_result.hv_Column11.D(), moban_s.mid_result.hv_Row2.D(), moban_s.mid_result.hv_Column2.D());

        moban_num++;
        Halcon_moban_all.push_back(moban_s);
    }

    //std::cout << "HALCON Refresh_Model_all finish!moban size:" << to_string(Halcon_moban_all.size()) << std::endl;
    SPDLOG_INFO("HALCON Refresh_Model_all finish!moban size:{}", Halcon_moban_all.size());
}

//͸�ӱ任
int hconAction::ImageToushiChange(HalconCpp::HObject& ho_ImageInput, HalconCpp::HObject& ho_TransImage)
{
    std::clock_t t1, t2;
    t1 = clock();

    HalconCpp::HObject ho_GrayImage, ho_ImageMean, ho_Region, ho_ConnectedRegions;
    HalconCpp::HObject ho_RegionTrans, ho_Contours, ho_ContoursSplit, ho_SortedRegions;
    HalconCpp::HTuple hv_Row1, hv_Column, hv_Phi, hv_Length1, hv_Length2, hv_HomMat2D1;
    HalconCpp::HTuple hv_X, hv_Y, hv_Number;
    HalconCpp::HObject ho_ObjectSelected;
    HTuple hv_Index1, hv_Row, hv_Col, hv_RowBegin, hv_ColBegin, hv_RowEnd, hv_ColEnd, hv_Nr, hv_Nc, hv_Dist;

    HalconCpp::HTuple hv_HomMat2D, hv_Covariance, hv_HomMat2DIdentity, hv_HomMat2DTranslate;

    //��������ͼƬת�Ҷ�ͼ
    Rgb1ToGray(ho_ImageInput, &ho_GrayImage);
    //ʹ�þ�ֵ�˲���������
    MeanImage(ho_GrayImage, &ho_ImageMean, 7, 7);
    //���Ҷ�ͼ�ͻҶ�ͼ�ı�Ե�������
    Threshold(ho_ImageMean, &ho_Region, 30, 255);
    Connection(ho_Region, &ho_ConnectedRegions);
    SelectShape(ho_ConnectedRegions, &ho_Region, "area", "and", 52297.9, 2e+06);
    SmallestRectangle2(ho_Region, &hv_Row1, &hv_Column, &hv_Phi, &hv_Length1, &hv_Length2);
    VectorAngleToRigid(hv_Row1, hv_Column, hv_Phi, hv_Row1, hv_Column, 0, &hv_HomMat2D1);
    AffineTransImage(ho_GrayImage, &ho_GrayImage, hv_HomMat2D1, "constant", "false");
    AffineTransRegion(ho_Region, &ho_Region, hv_HomMat2D1, "constant");

    //�ı��������״Ϊ͹��
    ShapeTrans(ho_Region, &ho_RegionTrans, "convex");

    //����XLD�����ؼ�������'border'�߿����ص���߿���Ϊ������
    GenContourRegionXld(ho_RegionTrans, &ho_Contours, "border");
    //��XLD�����ָ���߶Ρ�
    //SegmentContoursXld(ho_Contours, &ho_ContoursSplit, "lines", 5, 10, 3);

    SegmentContoursXld(ho_Contours, &ho_ContoursSplit, "lines", 9, 20, 3);
    //�����ı��εĶ���X����
    hv_X = HTuple();
    //�����ı��εĶ���y����
    hv_Y = HTuple();
    //�������������λ������
    SortContoursXld(ho_ContoursSplit, &ho_SortedRegions, "character", "true", "row");
    //����Ԫ���е�����
    CountObj(ho_SortedRegions, &hv_Number);

    //��ͼ����
    //SaveHobjectImg("D:/OpenCV_test/OpenCV/out/build/x64-Release/Testing/result-moban/" + to_string(now_dealImg_num) + "_ho_ImageMean.bmp", ho_ImageMean);
    //SaveHobjectImg("D:/OpenCV_test/OpenCV/out/build/x64-Release/Testing/result-moban/" + to_string(now_dealImg_num) + "_ho_GrayImage_after.bmp", ho_GrayImage);


    if (0 != (int(hv_Number != hv_ModelNumber))) {

        //std::cout << "HALCON ImageToushiChange img:" << to_string(now_dealImg_num) << ",hv_Number:" << to_string(hv_Number[0].D()) << ",hv_ModelNumber:" << to_string(hv_ModelNumber[0].D()) << std::endl;
        SPDLOG_INFO("HALCON ImageToushiChange img:{:d},hv_Number:{:f},hv_ModelNumber:{:f} , don't detect!", now_dealImg_num, hv_Number[0].D(), hv_ModelNumber[0].D());
        return -1;
    }
    else {

        HTuple end_val123 = hv_Number;
        HTuple step_val123 = 1;
        for (hv_Index1 = 1; hv_Index1.Continue(end_val123, step_val123); hv_Index1 += step_val123)
        {
            //��˳��ѡ������
            SelectObj(ho_SortedRegions, &ho_ObjectSelected, hv_Index1);
            //���ֱ��
            GetContourXld(ho_ObjectSelected, &hv_Row, &hv_Col);
            FitLineContourXld(ho_ObjectSelected, "tukey", -1, 0, 5, 2, &hv_RowBegin, &hv_ColBegin,
                &hv_RowEnd, &hv_ColEnd, &hv_Nr, &hv_Nc, &hv_Dist);
            //ͳһ����Ԫ��
            TupleConcat(hv_X, hv_RowBegin, &hv_X);
            TupleConcat(hv_Y, hv_ColBegin, &hv_Y);
        }
    }

    //���ݸ��ı任ǰ�ͱ任������ݼ���һ��ͶӰ����
    VectorToProjHomMat2d(hv_X, hv_Y, hv_ModelX, hv_ModelY, "normalized_dlt", HTuple(), HTuple(),
        HTuple(), HTuple(), HTuple(), HTuple(), &hv_HomMat2D, &hv_Covariance);

    HalconCpp::HTuple lens_x,lens_y;
    HalconCpp::TupleLength(hv_X, &lens_x);
    HalconCpp::TupleLength(hv_Y, &lens_y);

   // std::cout << "lens_x:" << lens_x[0].I() <<",lens_y:" << lens_y[0].I() << std::endl;
    if (lens_x[0].I() != lens_y[0].I()) {
        SPDLOG_INFO("HALCON ImageToushiChange img:{:d},lens_x:{:f},lens_y:{:f} , don't detect!", now_dealImg_num, lens_x[0].I(), lens_y[0].I());
        return -1;
    }

    calculate.delta_x = hv_ModelX[0].D() - hv_X[0].D();
    calculate.delta_y = hv_ModelY[0].D() - hv_Y[0].D();

    //std::cout << "delta_x:" << to_string(calculate.delta_x) << ",delta_y:" << to_string(calculate.delta_y) << std::endl;
    //std::cout << "VectorToProjHomMat2d " << ",hv_X:" << to_string(hv_X[0].D()) << ",hv_Y:" << to_string(hv_Y[0].D()) << ",hv_ModelX:" << to_string(hv_ModelX[0].D())
    //        << ",hv_ModelY:" << to_string(hv_ModelY[0].D()) << std::endl;

    //��ͼ��Ӧ��ͶӰ�任
    ProjectiveTransImage(ho_GrayImage, &ho_TransImage, hv_HomMat2D, "nearest_neighbor", "false", "false");
    
    //��ͶӰ�任�Ժ��ͼƬ��x����ƽ��6����
    /*HomMat2dIdentity(&hv_HomMat2DIdentity);
    HomMat2dTranslate(hv_HomMat2DIdentity, 0, 6, &hv_HomMat2DTranslate);
    AffineTransImage(ho_TransImage, &ho_TransImage, hv_HomMat2DTranslate, "constant", "false");
    */

    t2 = clock();

    SPDLOG_INFO("HALCON ImageToushiChange img:{:d},finish!usetime:{:d}", now_dealImg_num, t2 - t1);
    return 1;
}

void ImageThreadRun(int threadnum, hconAction_calculate& calculate, hconAction_moban& Model, HalconCpp::HObject& ho_TransImage, unsigned int now_img_num)
{
    std::clock_t t1, t2;
    t1 = clock();
    SPDLOG_INFO("HALCON ImageThreadRun[{:d}] start!", threadnum);
    HTuple hv_HomMat2DIdentity, hv_HomMat2DTranslate;
    //��ͶӰ�任�Ժ��ͼƬ��x����ƽ��6����
    if (Model.now_num < 8) {
        HomMat2dIdentity(&hv_HomMat2DIdentity);
        HomMat2dTranslate(hv_HomMat2DIdentity, 0, 6, &hv_HomMat2DTranslate);
        AffineTransImage(ho_TransImage, &ho_TransImage, hv_HomMat2DTranslate, "constant", "false");
    }

    //��ֵ�ָ������Black��White�ֱ�����ڵ�׵�
    HalconCpp::HTuple hv_BlackMin(Model.BlackMin);
    HalconCpp::HTuple hv_WhiteMin(Model.WhiteMin);
    HalconCpp::HTuple hv_BlackMax(Model.BlackMax);
    HalconCpp::HTuple hv_WhiteMax(Model.WhiteMax);

    HalconCpp::HObject ho_ImageResult, ho_RegionResult, ho_ConnectedRegions, ho_SelectedRegions;
    HalconCpp::HTuple hv_Area, hv_CterRowModel, hv_CenterColModel;
    HalconCpp::HTuple hv_AreaSum, hv_Flag;

    //�ڱ任���ͼƬ�Ͻ�ȡ���������
    ReduceDomain(ho_TransImage, Model.mid_result.ho_RegionDifference, &ho_ImageResult);
    //SPDLOG_INFO("HALCON thread:{:d} ReduceDomain finish!", threadnum);

    //ɸѡ���������
    Threshold(ho_ImageResult, &ho_RegionResult, hv_BlackMin.TupleConcat(hv_WhiteMin), hv_BlackMax.TupleConcat(hv_WhiteMax));
    //SPDLOG_INFO("HALCON thread:{:d} Threshold finish!", threadnum);

    Connection(ho_RegionResult, &ho_ConnectedRegions);
    //SPDLOG_INFO("HALCON thread:{:d} Connection finish!", threadnum);

    HalconCpp::HTuple hv_MinArea(Model.MinArea);
    HalconCpp::HTuple hv_MaxArea(Model.MaxArea);

    SelectShape(ho_ConnectedRegions, &ho_SelectedRegions, ((HTuple("column").Append("row")).Append("area")), "and",
        ((Model.mid_result.hv_Column11 + Model.XOffSet).TupleConcat(Model.mid_result.hv_Row11 + Model.YOffSet)).TupleConcat(hv_MinArea),
        ((Model.mid_result.hv_Column2 - Model.XOffSet).TupleConcat(Model.mid_result.hv_Row2 - Model.YOffSet)).TupleConcat(hv_MaxArea));
    //SPDLOG_INFO("HALCON thread:{:d} SelectShape finish!", threadnum);

    AreaCenter(ho_SelectedRegions, &hv_Area, &hv_CterRowModel, &hv_CenterColModel);  //  y x

    //SPDLOG_INFO("HALCON thread:{:d} AreaCenter finish!", threadnum);

    //��ͼ����
    //hconAction save;
    //save.SaveHobjectImg("D:/OpenCV_test/OpenCV/out/build/x64-Release/Testing/result-moban/" + to_string(now_img_num) + "_ho_ImageResult.bmp", ho_ImageResult);

    hv_AreaSum = hv_Area.TupleSum();
    hv_Flag = 0;

    HalconCpp::HTuple lens;
    HalconCpp::TupleLength(hv_AreaSum, &lens);

    if (lens[0].I() > 0 ) {
        hv_Flag = 1;
        //std::cout << "thread :" << to_string(threadnum) << ",hv_AreaSum lens:" << to_string(lens[0].I()) << ",hv_AreaSum:" << to_string(hv_AreaSum.D()) << ",flag:" << to_string(hv_Flag[0].I()) << std::endl;
    }
    else {
        hv_Flag = 0;
        //std::cout << "thread :" << to_string(threadnum) << ",hv_AreaSum lens:" << to_string(lens[0].I()) << ",flag:" << to_string(hv_Flag[0].I()) << std::endl;
    }

    t2 = clock();
    SPDLOG_INFO("HALCON thread:{:d}, t2 finish!", threadnum);

    halcon_result_mutex.lock();

    if (hv_Flag[0].I() == 1) {   //��ȱ��
        Detect_Result result;
        HalconCpp::HTuple detect_lens;
        HalconCpp::TupleLength(hv_CterRowModel, &detect_lens);

        //std::cout <<"detect_lens:" << detect_lens.I() <<",y:" << hv_CterRowModel[0].D() << ",x:" << hv_CenterColModel[0].D() << std::endl;
        if (detect_lens.I() > 5) detect_lens = 5;
        for (int detect_num = 0; detect_num < detect_lens.I(); detect_num++)
        {
            result.class_res = 5;   //��ī
            /*
            result.y1 = hv_CterRowModel[detect_num].D() - 20 - calculate.delta_y;
            result.x1 = hv_CenterColModel[detect_num].D() - 20 - calculate.delta_y;

            result.y2 = hv_CterRowModel[detect_num].D() + 20 - calculate.delta_x;
            result.x2 = hv_CenterColModel[detect_num].D() + 20 - calculate.delta_x;
            */
            result.y1 = hv_CterRowModel[detect_num].D() - 20 ;
            result.x1 = hv_CenterColModel[detect_num].D() - 20 ;

            result.y2 = hv_CterRowModel[detect_num].D() + 20;
            result.x2 = hv_CenterColModel[detect_num].D() + 20;

            result.result_str = "{\"class\":" + to_string(result.class_res) + ",\"config\":99" +
                +",\"ix1\":" + to_string(result.x1) + ",\"iy1\":" + to_string(result.y1)
                + ",\"ix2\":" + to_string(result.x2) + ",\"iy2\":" + to_string(result.y2) + "}";

            Halcon_Result.push_back(result);
        }
    }

    SPDLOG_INFO("HALCON thread:{:d},img:{:d},moban:{:d},lens:{:d},flag:{:d},usetime:{:d}", threadnum, now_img_num, Model.now_num, lens[0].I(), hv_Flag[0].I(), t2 - t1);

    halcon_result_mutex.unlock();
}

//����ģ��ȶԵ��̣߳�ÿ��ģ��һ���߳�
void hconAction::ImageThreadStart(HalconCpp::HObject& ImageInput)
{
    std::clock_t t1, t2;
    t1 = clock();

    Halcon_Result.clear();

    int thread_i;
    for (thread_i = 0; thread_i < Halcon_moban_all.size(); thread_i++) {
        Halcon_thread.push_back(std::thread(ImageThreadRun, thread_i, calculate, Halcon_moban_all[thread_i], ImageInput , now_dealImg_num));
    }

    t2 = clock();
    SPDLOG_INFO("HALCON ImageThreadStart usetime:{:d}", t2 - t1);
}

//is_detect = 1 ��ȱ��  is_detect = 0 ��ȱ��
void hconAction::ImageThreadJoin(vector<Detect_Result>& Result, int& is_detect)
{
    std::clock_t t1, t2;
    t1 = clock();

    int detect_num = 0;
    is_detect = 0;
    for (vector<std::thread>::iterator it = Halcon_thread.begin(); it != Halcon_thread.end(); ++it) {
        it->join();
    }

    detect_num = Halcon_Result.size();
    if (detect_num > 0) {
        Result.insert(Result.end(), Halcon_Result.begin(), Halcon_Result.end());  //����ϲ������ս����
        Halcon_Result.clear();
        is_detect = 1;   //��ȱ��
    }

    Halcon_thread.clear();
    t2 = clock();

    SPDLOG_INFO("HALCON ImageThreadJoin finish! is_detect:{:d},detect_num:{:d},usetime:{:d}", is_detect, detect_num, t2 - t1);
}

void hconAction::GetDataOfmoban(int num, int& x1, int& y1, int& x2, int& y2)
{
    int realnum = 0;
    for (realnum = 0; realnum <= Halcon_moban_all.size(); realnum++) {
        if (Halcon_moban_all[realnum].now_num == num)    break;
    }

    x1 = Halcon_moban_all[realnum].x1;
    y1 = Halcon_moban_all[realnum].y1;
    x2 = Halcon_moban_all[realnum].x2;
    y2 = Halcon_moban_all[realnum].y2;
}

int hconAction::GetNumOfmoban()
{
    return Halcon_moban_all.size();
}

void hconAction::SetNowImgNum(int num_now)
{
    now_dealImg_num = num_now;
}

/*
void hconAction::MatAndImageToushi(void *phalcon, cv::Mat ImageInput, int now_img_num)
{

}

void hconAction::ImageThreadTouShiStart(cv::Mat &ImageInput_mat)
{
    MatToToushi_thread = std::thread(&hconAction::MatAndImageToushi,this,ImageInput_mat, now_dealImg_num);
}*/