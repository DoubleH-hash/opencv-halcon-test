#include <iostream>
#include <cstring>
#include <vector>

#include <opencv2/opencv.hpp>
#define SPDLOG_ACTIVE_LEVEL SPDLOG_LEVEL_TRACE
#include "spdlog/spdlog.h"
#include "spdlog/cfg/env.h"
#include "spdlog/sinks/basic_file_sink.h"
#include "spdlog/sinks/stdout_sinks.h"
#include "spdlog/async.h"
#include "spdlog/sinks/rotating_file_sink.h"
#include "thread"

#include <opencv2/opencv.hpp>
#include <opencv2/cudawarping.hpp>
#include <opencv2/cudaarithm.hpp>

#include <torch/torch.h>
#include <fstream>

#include "Yolo.h"

using namespace cv;

using namespace std;



void init_log()
{
    try
    {
		spdlog::init_thread_pool(10000, 1);
        char log_file_name[256];
        DWORD process_id = GetCurrentProcessId();
        sprintf(log_file_name, "logs/basic-2d-log-%ld.txt", process_id);
        //printf("file name : %s", log_file_name);
		auto logger = spdlog::rotating_logger_mt<spdlog::async_factory>("basic_logger",string(log_file_name), 1024 * 1024 * 50, 3);
        //auto logger = spdlog::basic_logger_mt("basic_logger", "logs/basic-log.txt");
        spdlog::set_default_logger(logger);
        // change log pattern
        spdlog::set_pattern("[%Y-%m-%d %H:%M:%S.%e] [%l] [thread %t] [%@] > %v");
        SPDLOG_INFO("2d_hikvision node global log create successful");
        spdlog::flush_every(std::chrono::seconds(5));

        spdlog::flush_on(spdlog::level::info);

        std::cout << "Log init succeed!" << std::endl;
    }
    catch (const spdlog::spdlog_ex& ex)
    {
        std::cout << "Log init failed! " << ex.what() << std::endl;
    }
}


vector<cv::cuda::GpuMat> SlittingImage(const cv::cuda::GpuMat& matBody, const int& iNum)
{
    vector<cv::cuda::GpuMat> vctImageMat;

    int iImageWidth = (matBody.cols) / iNum;

    for (int i = 0; i < iNum; i++)
    {
        int iMatPartEnd = iImageWidth * (i + 1);
        if (matBody.cols < iMatPartEnd)
        {
            iMatPartEnd = matBody.cols;
        }
        cv::cuda::GpuMat matPart = matBody.colRange(iImageWidth * i, iImageWidth * (i + 1)).rowRange(0, matBody.rows).clone();
        SPDLOG_INFO("Get Gpumat::matPart: {:d} cols:{:d} rows:{:d}", i, matPart.cols, matPart.rows);
        vctImageMat.push_back(matPart);
    }

    return vctImageMat;
}

int main(int argc, char* argv[])
{  
    system("chcp 65001");
    init_log();

    SPDLOG_INFO("Spdlog version {}.{}.{}", SPDLOG_VER_MAJOR,SPDLOG_VER_MINOR,SPDLOG_VER_PATCH);
    spdlog::set_level(spdlog::level::info);
    
    int iHeight = 960;
    int iWidth = 960;
    int iDBBlock = 4;

    Yolo* m_pYolo;

    //ģ��·��
    m_pYolo = new Yolo("D:/OpenCV_test/OpenCV/out/build/x64-Release/0815.torchscript", "v8", true, true, iHeight, iWidth);
    //2.Ԥ��ģ��
    cv::cuda::GpuMat matGpu(iHeight, iWidth, CV_8UC3, Scalar(114, 114, 114));
    std::clock_t t1, t2;
    int32_t use_time;
    SPDLOG_INFO("first prediction:ih:{:d},iw:{:d} start!", iHeight, iWidth);
    for (size_t i = 0; i < 3; i++)
    {

        t1 = clock();
        m_pYolo->prediction(matGpu, iHeight, iWidth);
        t2 = clock();
        use_time = t2 - t1;
        SPDLOG_INFO("prediction:{:d},usetime:{:d}", i, use_time);
    }
    SPDLOG_INFO("first prediction:ih:{:d},iw:{:d} finish!", iHeight, iWidth);
    printf("first prediction finish!\r\n");

    //��ȡ��ͼƬ·��
    cv::Mat oriMatImage = cv::imread("D:/OpenCV_test/OpenCV/out/build/x64-Release/Testing/7567.bmp");
    cv::cuda::GpuMat matImage;
    matImage.upload(oriMatImage);
    vector<cv::cuda::GpuMat> vctMat = SlittingImage(matImage, 3);
    vector<cv::cuda::GpuMat>::iterator itMat = vctMat.begin();
    for (int i = 0; itMat != vctMat.end(); itMat++, i++) {
        cuda::GpuMat img_mat = *itMat;
        vector<torch::Tensor> r = m_pYolo->prediction(img_mat, 960, 960);

        SPDLOG_INFO("Callback end prediction image({:d})",  i);

       cv::Mat matDraw;
        (*itMat).download(matDraw);
        Mat img = m_pYolo->drawRectangle(matDraw, r[0]);
        //���ɵĽ��ͼƬ·��
        string strImage_file = "D:/OpenCV_test/OpenCV/out/build/x64-Release/Testing/"  + to_string(i + 1) + ".bmp";
        imwrite(strImage_file, img);
    }

    printf("finish !!!\r\n");

    return 0;
}