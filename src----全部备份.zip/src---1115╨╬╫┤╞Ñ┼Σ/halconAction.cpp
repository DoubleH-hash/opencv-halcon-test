#include <iostream>
#include <cstring>
#include <vector>
#include "thread"

#include <opencv2/opencv.hpp>
#include <opencv2/cudawarping.hpp>
#include <opencv2/cudaarithm.hpp>
#define SPDLOG_ACTIVE_LEVEL SPDLOG_LEVEL_TRACE
#include "spdlog/spdlog.h"
#include "spdlog/cfg/env.h"
#include "spdlog/sinks/basic_file_sink.h"
#include "spdlog/sinks/stdout_sinks.h"
#include "spdlog/async.h"
#include "spdlog/sinks/rotating_file_sink.h"

#include <torch/torch.h>
#include <fstream>

#include "stdio.h"
#include <future>

#include "windows.h"

#include "Halcon.h"
#include "HalconCpp.h"

#include "halconAction.h"
#include "HDevThread.h"
#include "HDevEngineCpp.h"

#include "CommonContent.h"

using namespace cv;
using namespace std;
using namespace HalconCpp;
using namespace HDevEngineCpp;

std::mutex halcon_result_mutex;
vector<Detect_Result> Halcon_Result;


HTuple hv_DeviceIdentifier, hv_DeviceHandle;


hconAction::hconAction()
{
    /*HalconԴ��*/

    SPDLOG_INFO("halconAction start!start GPU speed up...");

    //����GPU����
    //QueryAvailableComputeDevices(&hv_DeviceIdentifier);

    //OpenComputeDevice(HTuple(hv_DeviceIdentifier[0]), &hv_DeviceHandle);

    //SetComputeDeviceParam(hv_DeviceHandle, "alloc_pinned", "false");

    //InitComputeDevice(hv_DeviceHandle, "all");

    //ActivateComputeDevice(hv_DeviceHandle);  //����GPU

    SPDLOG_INFO("finish GPU speed up");
}

hconAction::~hconAction()
{
    SPDLOG_INFO("halconAction end!");

    //DeactivateComputeDevice(hv_DeviceHandle);  //ȡ������GPU
}

void GenPolygonPoints_COPY_2(HObject ho_GrayImage, HTuple* hv_Xl, HTuple* hv_Yl,
    HTuple* hv_iErrorCode)
{

    // Local iconic variables
    HObject  ho_Region, ho_ConnectedRegions, ho_SelectedRegions;
    HObject  ho_RegionUnion, ho_RegionTrans, ho_Contours, ho_ContoursSplit;
    HObject  ho_SelectedContours, ho_RegressContours, ho_UnionContours;
    HObject  ho_RegionLines;

    // Local control variables
    HTuple  hv_Row1, hv_Column, hv_Phi, hv_Length1;
    HTuple  hv_Length2, hv_RowBegin, hv_ColBegin, hv_RowEnd;
    HTuple  hv_ColEnd, hv_Nr, hv_Nc, hv_Dist, hv_Length, hv_X;
    HTuple  hv_Y, hv_index, hv_Y1Start, hv_X1Start, hv_Y1End;
    HTuple  hv_X1End, hv_Y2Start, hv_X2Start, hv_Y2End, hv_X2End;
    HTuple  hv_Row, hv_Col, hv_IsOverlapping;


    Threshold(ho_GrayImage, &ho_Region, 30, 255);
    Connection(ho_Region, &ho_ConnectedRegions);
    SelectShape(ho_ConnectedRegions, &ho_SelectedRegions, "area", "and", 150, 2e+6);
    Union1(ho_SelectedRegions, &ho_RegionUnion);
    //�任������״
    ShapeTrans(ho_RegionUnion, &ho_RegionTrans, "convex");
    SmallestRectangle2(ho_RegionTrans, &hv_Row1, &hv_Column, &hv_Phi, &hv_Length1,
        &hv_Length2);
    //Regon->xld
    GenContourRegionXld(ho_RegionTrans, &ho_Contours, "border");
    //�����ָ�(��)��ɸѡ
    SegmentContoursXld(ho_Contours, &ho_ContoursSplit, "lines", 20, 10, 20);
    SelectContoursXld(ho_ContoursSplit, &ho_SelectedContours, "contour_length", 100,
        20000, -0.5, 0.5);
    //���������ֱ��
    RegressContoursXld(ho_SelectedContours, &ho_RegressContours, "median", 3);
    UnionCollinearContoursXld(ho_RegressContours, &ho_UnionContours, 10, 1, 2, 0.1,
        "attr_keep");
    FitLineContourXld(ho_UnionContours, "tukey", -1, 0, 5, 2, &hv_RowBegin, &hv_ColBegin,
        &hv_RowEnd, &hv_ColEnd, &hv_Nr, &hv_Nc, &hv_Dist);
    GenRegionLine(&ho_RegionLines, hv_RowBegin, hv_ColBegin, hv_RowEnd, hv_ColEnd);
    TupleLength(hv_RowBegin, &hv_Length);
    if (0 != (int(hv_Length != 6)))
    {
        (*hv_iErrorCode) = 101;
        return;
    }
    if (0 != (int((hv_Phi.TupleAbs()) > (HTuple(10).TupleRad()))))
    {
        (*hv_iErrorCode) = 102;
        return;
    }
    //���㽻������
    hv_X = HTuple();
    hv_Y = HTuple();
    if (HDevWindowStack::IsOpen())
        DispObj(ho_GrayImage, HDevWindowStack::GetActive());
    for (hv_index = 0; hv_index <= 5; hv_index += 1)
    {
        if (0 != (int(hv_index == 5)))
        {
            //��һ��ֱ����ʼ��
            hv_Y1Start = HTuple(hv_RowBegin[hv_index]);
            hv_X1Start = HTuple(hv_ColBegin[hv_index]);
            hv_Y1End = HTuple(hv_RowEnd[hv_index]);
            hv_X1End = HTuple(hv_ColEnd[hv_index]);
            //�ڶ���ֱ�ߵ���ʼ��
            hv_Y2Start = ((const HTuple&)hv_RowBegin)[0];
            hv_X2Start = ((const HTuple&)hv_ColBegin)[0];
            hv_Y2End = ((const HTuple&)hv_RowEnd)[0];
            hv_X2End = ((const HTuple&)hv_ColEnd)[0];
        }
        else
        {
            //��һ��ֱ����ʼ��
            hv_Y1Start = HTuple(hv_RowBegin[hv_index]);
            hv_X1Start = HTuple(hv_ColBegin[hv_index]);
            hv_Y1End = HTuple(hv_RowEnd[hv_index]);
            hv_X1End = HTuple(hv_ColEnd[hv_index]);
            //�ڶ���ֱ�ߵ���ʼ��
            hv_Y2Start = HTuple(hv_RowBegin[hv_index + 1]);
            hv_X2Start = HTuple(hv_ColBegin[hv_index + 1]);
            hv_Y2End = HTuple(hv_RowEnd[hv_index + 1]);
            hv_X2End = HTuple(hv_ColEnd[hv_index + 1]);
        }
        //����ǵ�����
        IntersectionLines(hv_Y1Start, hv_X1Start, hv_Y1End, hv_X1End, hv_Y2Start, hv_X2Start,
            hv_Y2End, hv_X2End, &hv_Row, &hv_Col, &hv_IsOverlapping);
        hv_X = hv_X.TupleConcat(hv_Col);
        hv_Y = hv_Y.TupleConcat(hv_Row);
    }
    if (0 != (int(hv_ColBegin > 500)))
    {
        (*hv_Xl) = ((const HTuple&)hv_X)[(((((HTuple(5).Append(0)).Append(1)).Append(2)).Append(3)).Append(4))];
        (*hv_Yl) = ((const HTuple&)hv_Y)[(((((HTuple(5).Append(0)).Append(1)).Append(2)).Append(3)).Append(4))];
    }
    else
    {
        (*hv_Xl) = hv_X;
        (*hv_Yl) = hv_Y;
    }
    (*hv_iErrorCode) = 0;
    return;
}

void get_XY(HObject ho_ImageInput, HTuple* hv_X, HTuple* hv_Y, HTuple* hv_Number)
{

    // Local iconic variables
    HObject  ho_GrayImage, ho_ImageMean, ho_Region;
    HObject  ho_ConnectedRegions, ho_RegionTrans, ho_Contours;
    HObject  ho_ContoursSplit, ho_SortedRegions, ho_ObjectSelected;

    // Local control variables
    HTuple  hv_Row1, hv_Column, hv_Phi, hv_Length1;
    HTuple  hv_Length2, hv_HomMat2D1, hv_Index1, hv_Row, hv_Col;
    HTuple  hv_RowBegin, hv_ColBegin, hv_RowEnd, hv_ColEnd;
    HTuple  hv_Nr, hv_Nc, hv_Dist;

    Rgb1ToGray(ho_ImageInput, &ho_GrayImage);
    // �� ImageToushiChange ����һ��
    MeanImage(ho_GrayImage, &ho_ImageMean, 7, 7);
    //�Ҷ���ֵ�ָ������
    //binary_threshold (ImageMean, Region, 'max_separability', 'light', UsedThreshold)
    Threshold(ho_ImageMean, &ho_Region, 30, 255);
    Connection(ho_Region, &ho_ConnectedRegions);
    SelectShape(ho_ConnectedRegions, &ho_Region, "area", "and", 52297.9, 2e+06);
    SmallestRectangle2(ho_Region, &hv_Row1, &hv_Column, &hv_Phi, &hv_Length1, &hv_Length2);
    VectorAngleToRigid(hv_Row1, hv_Column, hv_Phi, hv_Row1, hv_Column, 0, &hv_HomMat2D1);
    AffineTransImage(ho_GrayImage, &ho_GrayImage, hv_HomMat2D1, "constant", "false");
    AffineTransRegion(ho_Region, &ho_Region, hv_HomMat2D1, "constant");
    //�ı��������״Ϊ͹��
    ShapeTrans(ho_Region, &ho_RegionTrans, "convex");

    //����XLD�����ؼ�������'border'�߿����ص���߿���Ϊ������
    GenContourRegionXld(ho_RegionTrans, &ho_Contours, "border");
    //��XLD�����ָ���߶�  �� ImageToushiChange ����һ��
    SegmentContoursXld(ho_Contours, &ho_ContoursSplit, "lines", 9, 20, 3);
    //�����ı��εĶ���X����
    (*hv_X) = HTuple();
    //�����ı��εĶ���y����
    (*hv_Y) = HTuple();
    //�������������λ������
    SortContoursXld(ho_ContoursSplit, &ho_SortedRegions, "character", "true", "row");
    //����Ԫ���е�����
    CountObj(ho_SortedRegions, &(*hv_Number));
    {
        HTuple end_val26 = (*hv_Number);
        HTuple step_val26 = 1;
        for (hv_Index1 = 1; hv_Index1.Continue(end_val26, step_val26); hv_Index1 += step_val26)
        {
            //��˳��ѡ������
            SelectObj(ho_SortedRegions, &ho_ObjectSelected, hv_Index1);
            //���ֱ��
            GetContourXld(ho_ObjectSelected, &hv_Row, &hv_Col);
            FitLineContourXld(ho_ObjectSelected, "tukey", -1, 0, 5, 2, &hv_RowBegin, &hv_ColBegin,
                &hv_RowEnd, &hv_ColEnd, &hv_Nr, &hv_Nc, &hv_Dist);
            //ͳһ����Ԫ��
            TupleConcat((*hv_X), hv_RowBegin, &(*hv_X));
            TupleConcat((*hv_Y), hv_ColBegin, &(*hv_Y));

        }
    }
    return;
}

Mat hconAction::HImageToMat(const HalconCpp::HImage& hImg)
{

    cv::Mat mat;
    int channels = hImg.CountChannels()[0].I();
    HalconCpp::HImage hImage = hImg.ConvertImageType("byte");

    Hlong hW = 0, hH = 0;
    HalconCpp::HString cType;

    if (channels == 1) {
        void* r = hImage.GetImagePointer1(&cType, &hW, &hH);
        mat.create(int(hH), int(hW), CV_8UC1);
        memcpy(mat.data, static_cast<unsigned char*>(r), int(hW * hH));
    }
    else if (channels == 3) {
        void* r = NULL, * g = NULL, * b = NULL;

        hImage.GetImagePointer3(&r, &g, &b, &cType, &hW, &hH);
        mat.create(int(hH), int(hW), CV_8UC3);

        std::vector<cv::Mat> vec(3);
        vec[0].create(int(hH), int(hW), CV_8UC1);
        vec[1].create(int(hH), int(hW), CV_8UC1);
        vec[2].create(int(hH), int(hW), CV_8UC1);

        memcpy(vec[2].data, static_cast<unsigned char*>(r), int(hW * hH));
        memcpy(vec[1].data, static_cast<unsigned char*>(g), int(hW * hH));
        memcpy(vec[0].data, static_cast<unsigned char*>(b), int(hW * hH));
        cv::merge(vec, mat);
    }
    return mat;
}

Mat hconAction::HObjectToMat(const HalconCpp::HObject& hObj)
{
    HalconCpp::HImage hImg(hObj);
    return HImageToMat(hImg);
}

HalconCpp::HObject hconAction::MatToHObject(const Mat& image)
{
    HalconCpp::HObject Hobj = HalconCpp::HObject();
    int hgt = image.rows;
    int wid = image.cols;
    int i;
    if (image.type() == CV_8UC3)
    {
        std::vector<Mat> imgchannel;
        split(image, imgchannel);
        Mat imgB = imgchannel[0];
        Mat imgG = imgchannel[1];
        Mat imgR = imgchannel[2];
        uchar* dataR = new uchar[hgt * wid];
        uchar* dataG = new uchar[hgt * wid];
        uchar* dataB = new uchar[hgt * wid];
        for (i = 0; i < hgt; i++)
        {
            memcpy(dataR + wid * i, imgR.data + imgR.step * i, wid);
            memcpy(dataG + wid * i, imgG.data + imgG.step * i, wid);
            memcpy(dataB + wid * i, imgB.data + imgB.step * i, wid);
        }
        HalconCpp::GenImage3(&Hobj, "byte", wid, hgt, (Hlong)dataR, (Hlong)dataG, (Hlong)dataB);
        delete[]dataR;
        delete[]dataG;
        delete[]dataB;
        dataR = NULL;
        dataG = NULL;
        dataB = NULL;
    }
    else if (image.type() == CV_8UC1)
    {
        uchar* data = new uchar[hgt * wid];
        for (i = 0; i < hgt; i++)
            memcpy(data + wid * i, image.data + image.step * i, wid);
        HalconCpp::GenImage1(&Hobj, "byte", wid, hgt, (Hlong)data);
        delete[] data;
        data = NULL;
    }
    return Hobj;
}

HalconCpp::HImage hconAction::MatToHImage(const Mat& image)
{
    HalconCpp::HImage hImg(MatToHObject(image));
    return hImg;
}

void hconAction::SaveHobjectImg(string path, HObject &Hobject_in)
{
    Mat out = HObjectToMat(Hobject_in);
    imwrite(path, out);
}

int hconAction::GetIni(string file_path, string apname, string partname)
{
    int num = 0;
    char getchr[10];	//���������ļ��ַ��Ļ�����
    DWORD res;		//����ֵ
    file_path += "config.ini";
    res = GetPrivateProfileString(apname.c_str(), partname.c_str(), "", getchr, sizeof(getchr), file_path.c_str());

    if (res > 0) {//˵���ò�������
        num = atoi(getchr);
    }
    else {
        num = -1;
    }

    //std::cout << "GetIni-------file_path:" << file_path << ",apaname:" << apname <<",partname:" << partname << ",get res:" << to_string(res) << ",get num =" << to_string(num) << std::endl;

    return num;
}

//�������ļ���д����
int hconAction::SetIni(string file_path, string apname, string partname, int set_num)
{
    //����WritePrivateProfileString("LiMing", "Sex", "Man", lpPath);
    string num_str = to_string(set_num);
    WritePrivateProfileString(apname.c_str(), partname.c_str(), num_str.c_str(), file_path.c_str());
}

//����ģ������
void hconAction::HALCON_Refresh_Model_all(string filePath_moban)
{
    int ini_result = 0;
    int moban_num = 1;

    Halcon_moban_all.clear();
    SPDLOG_INFO("HALCON Refresh_Model_all start!moban size:{},path:{}", Halcon_moban_all.size(), filePath_moban);

    /*ģ��ͼ��*/
    string ImageModel_path = filePath_moban + "0.bmp";
    HObject ho_ImageModel;
    ReadImage(&ho_ImageModel, ImageModel_path.c_str());

    HalconCpp::HObject ho_ImageGrayM;
    HalconCpp::HTuple hv_iErrorCode;
    Rgb1ToGray(ho_ImageModel, &ho_ImageGrayM);
    //��ȡģ��6���ǵ�
    GenPolygonPoints_COPY_2(ho_ImageGrayM, &calculate.hv_XM, &calculate.hv_YM, &hv_iErrorCode);

    while (1) {
        hconAction_moban moban_s;
        string mobanname = "moban" + to_string(moban_num);
        moban_s.x1 = GetIni(filePath_moban, mobanname, "x1");
        if (moban_s.x1 == -1) break;   //�����ļ��޸�ģ�������
        moban_s.y1 = GetIni(filePath_moban, mobanname, "y1");
        moban_s.x2 = GetIni(filePath_moban, mobanname, "x2");
        moban_s.y2 = GetIni(filePath_moban, mobanname, "y2");

        moban_s.BlackMin = GetIni(filePath_moban, mobanname, "BlackMin");
        moban_s.WhiteMin = GetIni(filePath_moban, mobanname, "WhiteMin");
        moban_s.BlackMax = GetIni(filePath_moban, mobanname, "BlackMax");
        moban_s.WhiteMax = GetIni(filePath_moban, mobanname, "WhiteMax");

        moban_s.RatioDila = (float)GetIni(filePath_moban, mobanname, "RatioDila") / 10.0;
        moban_s.DiffThr = GetIni(filePath_moban, mobanname, "DiffThr");
        moban_s.DiffThrD = (float)GetIni(filePath_moban, mobanname, "DiffThrD") / 10.0;
        moban_s.MinArea = GetIni(filePath_moban, mobanname, "MinArea");
        moban_s.MaxArea = GetIni(filePath_moban, mobanname, "MaxArea");

        moban_s.XOffSet = GetIni(filePath_moban, mobanname, "XOffSet");
        moban_s.YOffSet = GetIni(filePath_moban, mobanname, "YOffSet");

        moban_s.now_num = moban_num;

        /*ģ�����꣺Row(y),Col(x)*/
        HalconCpp::HTuple Row1(moban_s.y1);
        HalconCpp::HTuple Col1(moban_s.x1);
        HalconCpp::HTuple Row2(moban_s.y2);
        HalconCpp::HTuple Col2(moban_s.x2);

        //��ֵ�ָ������Black��White�ֱ�����ڵ�׵�
        HalconCpp::HTuple hv_BlackMin(moban_s.BlackMin);
        HalconCpp::HTuple hv_WhiteMin(moban_s.WhiteMin);
        HalconCpp::HTuple hv_BlackMax(moban_s.BlackMax);
        HalconCpp::HTuple hv_WhiteMax(moban_s.WhiteMax);
        HalconCpp::HTuple hv_RatioDila(moban_s.RatioDila);

        HalconCpp::HObject ho_ModelRegion, ho_TemplateImageM, ho_RegionM, ho_RegionDilationM;
        HalconCpp::HObject ho_GrayModel, ho_GrayShape;
        HalconCpp::HTuple hv_XM, hv_YM, hv_iErrorCode, hv_AreaModel, hv_RowModel, hv_ColumnModel;
        HalconCpp::HTuple hv_AreaLoc;

        //��ȡ�������
        GenRectangle1(&ho_ModelRegion, Row1, Col1, Row2, Col2);
        ReduceDomain(ho_ImageGrayM, ho_ModelRegion, &ho_TemplateImageM);
        Threshold(ho_TemplateImageM, &ho_RegionM, hv_BlackMin.TupleConcat(hv_WhiteMin),
            hv_BlackMax.TupleConcat(hv_WhiteMax));
        DilationCircle(ho_RegionM, &ho_RegionDilationM, hv_RatioDila);
        Difference(ho_ModelRegion, ho_RegionDilationM, &moban_s.mid_result.ho_RegionIntersection);
        //����ģ�����ͨ�����
        AreaCenter(ho_RegionM, &hv_AreaModel, &hv_RowModel, &hv_ColumnModel);

        //������״ƥ����
        Rgb1ToGray(ho_ImageModel, &ho_GrayModel);
        //GenRectangle1(&ho_ModelRegion, 392.215, 1950.94, 434.182, 2002.19);
        AreaCenter(ho_ModelRegion, &hv_AreaLoc, &moban_s.mid_result.hv_RowLoc, &moban_s.mid_result.hv_ColLoc);
        ReduceDomain(ho_GrayModel, ho_ModelRegion, &ho_GrayShape);
        CreateShapeModel(ho_GrayShape, "auto", -0.1, 0.2, "auto", "auto", "use_polarity",
            "auto", "auto", &moban_s.mid_result.hv_ModelID);

        //std::cout << "HALCON Refresh_Model_all moban:" << to_string(moban_s.now_num) << ",y1:" << to_string(moban_s.y1) << ",x1:" << to_string(moban_s.x1) << ",RatioDila:" << to_string(hv_RatioDila[0].D())<<
        //    ",hv_Row11:" << to_string(moban_s.mid_result.hv_Row11[0].D()) << ",hv_Column11:" << to_string(moban_s.mid_result.hv_Column11[0].D()) << ",hv_Row2:" << to_string(moban_s.mid_result.hv_Row2[0].D()) << ",hv_Column2:" << to_string(moban_s.mid_result.hv_Column2[0].D())
        //<< std::endl;

        SPDLOG_INFO("HALCON Refresh_Model_all push moban now_num:{:d},y1:{:d},x1:{:d},RatioDila:{:f},DiffThrD:{:f}",
            moban_s.now_num, moban_s.y1, moban_s.x1, moban_s.RatioDila, moban_s.DiffThrD);

        moban_num++;
        Halcon_moban_all.push_back(moban_s);
    }

    //std::cout << "HALCON Refresh_Model_all finish!moban size:" << to_string(Halcon_moban_all.size()) << std::endl;
    SPDLOG_INFO("HALCON Refresh_Model_all finish!moban size:{}", Halcon_moban_all.size());
}

//��ƷͼƬ�м�ı任����
int hconAction::ImageChange(HalconCpp::HObject& ho_ImageInput, HalconCpp::HObject& ho_TransImage)
{
    std::clock_t t1, t2;
    t1 = clock();
    HalconCpp::HObject ho_GrayImage;
    HalconCpp::HTuple hv_Xl, hv_Yl, hv_iErrorCode, hv_HomMat2D;


    //����������ζ���
    Rgb1ToGray(ho_ImageInput, &ho_GrayImage);
    GenPolygonPoints_COPY_2(ho_GrayImage, &hv_Xl, &hv_Yl, &hv_iErrorCode);
    if(0 != (int(hv_iErrorCode != 0))){   //�ǵ��ȡʧ��
        return -1;
    }

    //ͶӰ�任
    HomVectorToProjHomMat2d(hv_Yl, hv_Xl, (((((HTuple(1).Append(1)).Append(1)).Append(1)).Append(1)).Append(1)),
        calculate.hv_YM, calculate.hv_XM, (((((HTuple(1).Append(1)).Append(1)).Append(1)).Append(1)).Append(1)),
        "normalized_dlt", &hv_HomMat2D);
    ProjectiveTransImage(ho_GrayImage, &ho_TransImage, hv_HomMat2D, "bilinear", "false",
        "false");

    t2 = clock();

    SPDLOG_INFO("HALCON ImageChange img:{:d},finish!usetime:{:d}", now_dealImg_num, t2 - t1);
    return 1;
}

void ImageThreadRun(int threadnum, hconAction_calculate& calculate, hconAction_moban& Model, HalconCpp::HObject& ho_TransImage, unsigned int now_img_num)
{
    std::clock_t t1, t2;
    t1 = clock();
    SPDLOG_INFO("HALCON ImageThreadRun[{:d}] start!", threadnum);

    //��ֵ�ָ������Black��White�ֱ�����ڵ�׵�
    HalconCpp::HTuple hv_BlackMin(Model.BlackMin);
    HalconCpp::HTuple hv_WhiteMin(Model.WhiteMin);
    HalconCpp::HTuple hv_BlackMax(Model.BlackMax);
    HalconCpp::HTuple hv_WhiteMax(Model.WhiteMax);

    HalconCpp::HTuple hv_MinArea(Model.MinArea);
    HalconCpp::HTuple hv_MaxArea(Model.MaxArea);

    HalconCpp::HTuple hv_Row, hv_Col, hv_Angle, hv_Score, hv_Length, hv_Flag;

    HalconCpp::HTuple hv_HomMat2DIdentity, hv_HomMat2DTranslate;
    HalconCpp::HObject ho_ImageAffineTrans, ho_ReducedBackground;
    HalconCpp::HObject ho_BinaryBackground, ho_ConnectedBackground, ho_SelectedRegions, ho_Rectangle;
    HalconCpp::HTuple hv_Area, hv_Row1, hv_Column1;
    HalconCpp::HTuple lens;
    HalconCpp::HTuple hv_Num(0), hv_AreaSum;
    HalconCpp::HTuple hv_Row11, hv_Column11, hv_Row2, hv_Column2;

    //��λ
    FindShapeModel(ho_TransImage, Model.mid_result.hv_ModelID, -0.1, 0.2, 0.2, 1, 0.5, "least_squares",
        0, 0.9, &hv_Row, &hv_Col, &hv_Angle, &hv_Score);

    TupleLength(hv_Row, &hv_Length);

    //std::cout << "thread :" << to_string(threadnum) << ",hv_Length:" << to_string(hv_Length[0].I()) << std::endl;

    if (hv_Length.I() == 0) {
        //��״��λʧ��
        hv_Flag = 2;
        goto detectfail;
    }

    //��ͶӰ�任�Ժ��ͼƬ������״ƥ�����Ľ������ƽ��
    HomMat2dIdentity(&hv_HomMat2DIdentity);
    HomMat2dTranslate(hv_HomMat2DIdentity, Model.mid_result.hv_RowLoc - hv_Row, Model.mid_result.hv_ColLoc - hv_Col, &hv_HomMat2DTranslate);
    AffineTransImage(ho_TransImage, &ho_ImageAffineTrans, hv_HomMat2DTranslate, "constant",
        "false");

    //��ⱳ��ȱ��
    ReduceDomain(ho_ImageAffineTrans, Model.mid_result.ho_RegionIntersection, &ho_ReducedBackground);
    Threshold(ho_ReducedBackground, &ho_BinaryBackground, hv_BlackMin, hv_BlackMax);
    Connection(ho_BinaryBackground, &ho_ConnectedBackground);
    SelectShape(ho_ConnectedBackground, &ho_SelectedRegions, "area", "and", hv_MinArea, hv_MaxArea);
    AreaCenter(ho_SelectedRegions, &hv_Area, &hv_Row1, &hv_Column1);
    HalconCpp::TupleLength(hv_Area, &hv_Num);

    hv_Flag = 0;
   
    if (hv_Num.I() > 0) {
        if (hv_Num.I() > 3) {
            Union1(ho_SelectedRegions, &ho_SelectedRegions);  //ȱ�������ں�
        }
        //����Ӿ��α��ȱ��λ��
        SmallestRectangle1(ho_SelectedRegions, &hv_Row11, &hv_Column11, &hv_Row2, &hv_Column2);
        hv_Flag = 1;
    }
    else {
        hv_Flag = 0;
    }

//��״��λʧ��
detectfail:
    t2 = clock();

    halcon_result_mutex.lock();

    if (hv_Flag.I() == 1) {   //��ȱ��
        Detect_Result result;
        HalconCpp::HTuple detect_lens;
        HalconCpp::TupleLength(hv_Row11, &detect_lens);

        if (detect_lens.I() > 5) detect_lens = 5;
        for (int detect_num = 0; detect_num < detect_lens.I(); detect_num++)
        {
            result.class_res = 5;   //��ī
            result.y1 = hv_Row11[detect_num].D() - 20 ;
            result.x1 = hv_Column11[detect_num].D() - 20 ;
            result.y2 = hv_Row11[detect_num].D() + 20 ;
            result.x2 = hv_Column11[detect_num].D() + 20 ;

            result.result_str = "{\"class\":" + to_string(result.class_res) + ",\"config\":99" +
                +",\"ix1\":" + to_string(result.x1) + ",\"iy1\":" + to_string(result.y1)
                + ",\"ix2\":" + to_string(result.x2) + ",\"iy2\":" + to_string(result.y2) + "}";

            Halcon_Result.push_back(result);
        }
    }
    else if (hv_Flag.I() == 2) {   //��״��λʧ��
        Detect_Result result;
        result.class_res = 5;   //��ī
        result.y1 = Model.y1;
        result.x1 = Model.x1;
        result.y2 = Model.y2;
        result.x2 = Model.x2;
        result.result_str = "{\"class\":" + to_string(result.class_res) + ",\"config\":99" +
            +",\"ix1\":" + to_string(result.x1) + ",\"iy1\":" + to_string(result.y1)
            + ",\"ix2\":" + to_string(result.x2) + ",\"iy2\":" + to_string(result.y2) + "}";

        Halcon_Result.push_back(result);
    }

    halcon_result_mutex.unlock();
    SPDLOG_INFO("HALCON thread:{:d},img:{:d},moban:{:d},hv_Length:{:d},flag:{:d},usetime:{:d}", threadnum, now_img_num, Model.now_num, hv_Length.I(), hv_Flag.I(), t2 - t1);
}

//����ģ��ȶԵ��̣߳�ÿ��ģ��һ���߳�
void hconAction::ImageThreadStart(HalconCpp::HObject& ImageInput)
{
    std::clock_t t1, t2;
    t1 = clock();

    //Halcon_Result.clear();

    int thread_i;
    for (thread_i = 0; thread_i < Halcon_moban_all.size(); thread_i++) {
        Halcon_thread.push_back(std::thread(ImageThreadRun, thread_i, calculate, Halcon_moban_all[thread_i], ImageInput , now_dealImg_num));
    }

    t2 = clock();
    SPDLOG_INFO("HALCON ImageThreadStart usetime:{:d}", t2 - t1);
}

//is_detect = 1 ��ȱ��  is_detect = 0 ��ȱ��
void hconAction::ImageThreadJoin(vector<Detect_Result>& Result, int& is_detect)
{
    std::clock_t t1, t2;
    t1 = clock();

    int detect_num = 0;
    is_detect = 0;
    for (vector<std::thread>::iterator it = Halcon_thread.begin(); it != Halcon_thread.end(); ++it) {
        it->join();
    }

    detect_num = Halcon_Result.size();
    if (detect_num > 0) {
        Result.insert(Result.end(), Halcon_Result.begin(), Halcon_Result.end());  //����ϲ������ս����
        Halcon_Result.clear();
        is_detect = 1;   //��ȱ��
    }

    Halcon_thread.clear();
    t2 = clock();

    SPDLOG_INFO("HALCON ImageThreadJoin finish! is_detect:{:d},detect_num:{:d},usetime:{:d}", is_detect, detect_num, t2 - t1);
}

void hconAction::GetDataOfmoban(int num, int& x1, int& y1, int& x2, int& y2)
{
    int realnum = 0;
    for (realnum = 0; realnum <= Halcon_moban_all.size(); realnum++) {
        if (Halcon_moban_all[realnum].now_num == num)    break;
    }

    x1 = Halcon_moban_all[realnum].x1;
    y1 = Halcon_moban_all[realnum].y1;
    x2 = Halcon_moban_all[realnum].x2;
    y2 = Halcon_moban_all[realnum].y2;
}

int hconAction::GetNumOfmoban()
{
    return Halcon_moban_all.size();
}

void hconAction::SetNowImgNum(int num_now)
{
    now_dealImg_num = num_now;
}

